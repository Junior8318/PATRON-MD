const chalk = require("chalk")
const fs = require("fs")
//auto presence update
global.autoTyping = false //auto tying in gc (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.autoblockmorroco = true //auto block 212 (true to on, false to off)
global.autokickmorroco = true //auto kick 212 (true to on, false to off) 
global.antispam = false//auto kick spammer (true to on, false to off)
//===============SETTING MENU==================\\
var _0x6e9f5f = _0x440c;
function _0x440c(_0xff7e8a, _0x55b825) {
  var _0x53568b = _0x5356();
  return _0x440c = function (_0x440c89, _0x6c964e) {
    _0x440c89 = _0x440c89 - 395;
    var _0x4b10d4 = _0x53568b[_0x440c89];
    return _0x4b10d4;
  }, _0x440c(_0xff7e8a, _0x55b825);
}
(function (_0x5f11d9, _0x4185c9) {
  var _0x2f3c55 = _0x440c, _0x18de9f = _0x5f11d9();
  while (true) {
    try {
      var _0x2ac68b = parseInt(_0x2f3c55(405)) / 1 * (parseInt(_0x2f3c55(401)) / 2) + parseInt(_0x2f3c55(411)) / 3 + -parseInt(_0x2f3c55(409)) / 4 + -parseInt(_0x2f3c55(404)) / 5 * (-parseInt(_0x2f3c55(397)) / 6) + parseInt(_0x2f3c55(399)) / 7 + parseInt(_0x2f3c55(403)) / 8 + -parseInt(_0x2f3c55(412)) / 9;
      if (_0x2ac68b === _0x4185c9) break; else _0x18de9f.push(_0x18de9f.shift());
    } catch (_0x4efa13) {
      _0x18de9f.push(_0x18de9f.shift());
    }
  }
}(_0x5356, 611392), global[_0x6e9f5f(400)] = fs[_0x6e9f5f(406)](_0x6e9f5f(414)), global.ig = _0x6e9f5f(408), global.yt = _0x6e9f5f(398), global.ttowner = "justt.patron", global[_0x6e9f5f(402)] = _0x6e9f5f(396), global[_0x6e9f5f(407)] = [_0x6e9f5f(395)], global[_0x6e9f5f(410)] = _0x6e9f5f(395), global.socialm = "GitHub: Itzpatron", global.location = _0x6e9f5f(413));
function _0x5356() {
  var _0x2d608b = ["2TiYyRi", "ownername", "4848248JOyFIO", "10285nogbjK", "24551hmyaFj", "readFileSync", "owner", "justt.patron", "4122452LsfHwQ", "ownernomer", "3122538rKjRfI", "13069737fNnLij", "Nigeria", "./data/image/thumb.jpg", "2348133729715", "PATRON 🚹", "996yvEvRn", "Itzpatron1", "7569156ZVpYsb", "thumbnail"];
  _0x5356 = function () {
    return _0x2d608b;
  };
  return _0x5356();
}

//==================setting bot===========================\\
var _0x1bcf00 = _0xe1c6;
function _0xe1c6(_0x488713, _0x4b148) {
  var _0x8e0965 = _0x8e09();
  return _0xe1c6 = function (_0xe1c6d, _0x1f51fe) {
    _0xe1c6d = _0xe1c6d - 127;
    var _0x98491e = _0x8e0965[_0xe1c6d];
    return _0x98491e;
  }, _0xe1c6(_0x488713, _0x4b148);
}
function _0x8e09() {
  var _0x15a2b3 = ["ownerNumber", "2348133729715", "1042636teAGzd", "wagc", "websitex", "botnumber", "Sticker created by", "2348133729715@s.whatsapp.net", "2VoTTbt", "ᴘᴀᴛʀᴏɴ-ᴍᴅ", "packname", "460476jKclmm", "ᴘᴀᴛʀᴏɴ-ᴍᴅ 🚹", "331209drywgW", "https://github.com/Itzpatron/PATRON-MD", "ownernumber", "ᴘᴀᴛʀᴏɴ-ᴍᴅ🚹", "1256664XwfMbY", "10WbDnKq", "author", "456740fytdfb", "38255xwXZfH", "6oiKDdL", "botscript", "botname", "https://whatsapp.com/channel/0029Val0s0rIt5rsIDPCoD2q", "160282IElaUI"];
  _0x8e09 = function () {
    return _0x15a2b3;
  };
  return _0x8e09();
}
(function (_0x273843, _0xd8f9fc) {
  var _0x5a6f8a = _0xe1c6, _0x266e89 = _0x273843();
  while (true) {
    try {
      var _0x236534 = parseInt(_0x5a6f8a(148)) / 1 + -parseInt(_0x5a6f8a(130)) / 2 * (-parseInt(_0x5a6f8a(135)) / 3) + -parseInt(_0x5a6f8a(142)) / 4 + parseInt(_0x5a6f8a(143)) / 5 * (-parseInt(_0x5a6f8a(144)) / 6) + -parseInt(_0x5a6f8a(151)) / 7 + parseInt(_0x5a6f8a(139)) / 8 + parseInt(_0x5a6f8a(133)) / 9 * (-parseInt(_0x5a6f8a(140)) / 10);
      if (_0x236534 === _0xd8f9fc) break; else _0x266e89.push(_0x266e89.shift());
    } catch (_0x5bc448) {
      _0x266e89.push(_0x266e89.shift());
    }
  }
}(_0x8e09, 105820), global[_0x1bcf00(146)] = _0x1bcf00(131), global[_0x1bcf00(137)] = _0x1bcf00(150), global[_0x1bcf00(127)] = "2348133729715", global.ownername = _0x1bcf00(138), global[_0x1bcf00(149)] = [_0x1bcf00(129)], global.ownerweb = "https://whatsapp.com/channel/0029Val0s0rIt5rsIDPCoD2q", global[_0x1bcf00(153)] = _0x1bcf00(147), global[_0x1bcf00(152)] = _0x1bcf00(147), global.saluran = _0x1bcf00(147), global.themeemoji = "🚹", global.wm = "ᴘᴀᴛʀᴏɴ-ᴍᴅ", global[_0x1bcf00(145)] = _0x1bcf00(136), global[_0x1bcf00(132)] = _0x1bcf00(128), global[_0x1bcf00(141)] = _0x1bcf00(134))
global.creator = "2348133729715@s.whatsapp.net"
global.bankname = "MONIEPOINT"
global.banknumber = "5518447058"
global.bankowner = "FADARE"
//======================== CPANEL COMMAND ===========================\\
global.domain = '-' // Fill in your domain, don't put a / at the end of the link
global.apikey = '-' // Fill Apikey
global.capikey = '-' // Fill Apikey
//=========================================================//
//Server create panel egg pm2
global.apikey2 = '-' // Fill Apikey
global.capikey2 = '-' // Fill Apikey
global.domain2 = '-' // Fill Domain
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //don't change it

global.eggsnya2 = '15' // ID of eggs used
global.location2 = '1' // id location
//===========================//
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // ID of eggs used
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
//===========================//

global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.prefix = ['!','.','#','&']
global.sessionName = 'session'
global.hituet = 0
//media target
global.thum = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./data/image/thumb.jpg") //ur logo pic
global.err4r = fs.readFileSync("./data/image/thumb.jpg") //ur error pic
global.thumb = fs.readFileSync("./data/image/thumb.jpg") //ur thumb pic
global.defaultpp = fs.readFileSync("./data/image/thumb.jpg") //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

//messages
function PATRONm(){var p=['ʏᴏᴏ\x20ʙʀᴏ\x20ɢᴛꜰ.\x20ᴛʜɪꜱ\x20ꜰᴇᴀᴛᴜʀᴇ\x20ᴄᴀɴ\x20ᴏɴʟʏ\x20ʙᴇ\x20ᴜꜱᴇᴅ\x20ʙʏ\x20ʙᴏᴛ\x20ᴏᴡɴᴇʀꜱ.\x20🚹','226680MdAWHj','3351492uLlKFH','ɪᴛ\x27ꜱ\x20ᴏꜰꜰ\x20ꜱɪʀ🚹','ᴍᴀᴋᴇ\x20ᴍᴇ\x20ᴀᴅᴍɪɴ\x20ꜰɪʀꜱᴛ\x20ɴɪɢɢᴀ.\x20🚹','ʏᴏᴏ\x20ꜱᴏʀʀʏ,\x20ᴇʀʀᴏʀ\x20ꜰᴇᴀᴛᴜʀᴇ,\x20ᴘʟᴇᴀꜱᴇ\x20ᴄʜᴀᴛ\x20ᴡɪᴛʜ\x20ᴛʜᴇ\x20ʙᴏᴛ\x20ᴅᴇᴠᴇʟᴏᴘᴇʀ\x20ꜱᴏ\x20ɪᴛ\x20ᴄᴀɴ\x20ʙᴇ\x20ꜰɪxᴇᴅ\x20ɪᴍᴍᴇᴅɪᴀᴛᴇʟʏ.\x20🚹','327048ygnDxl','ʏᴏᴏ\x20ᴍᴀɴ,\x20ʏᴏᴜ\x20ᴄʀᴀᴢʏ?\x20ᴛʜɪꜱ\x20ꜰᴇᴀᴛᴜʀᴇ\x20ᴄᴀɴ\x20ᴏɴʟʏ\x20ʙᴇ\x20ᴜꜱᴇᴅ\x20ɪɴ\x20ɢʀᴏᴜᴘꜱ.\x20🚹','6VGUVlw','10RFKFPL','ʜᴇʜᴇ,\x20*ɪᴛ\x20ᴡᴀꜱ\x20ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟ🚹*','10zmJfwV','ʙʀᴜʜ\x20ᴡᴛꜰ.\x20ᴛʜɪꜱ\x20ꜰᴇᴀᴛᴜʀᴇ\x20ᴄᴀɴ\x20ᴏɴʟʏ\x20ʙᴇ\x20ᴜꜱᴇᴅ\x20ɪɴ\x20ᴘʀɪᴠᴀᴛᴇ\x20ᴄʜᴀᴛ.\x20🚹','ᴡʜᴇʀᴇ\x27ꜱ\x20ᴛʜᴇ\x20ʟɪɴᴋ?🚹','20935607OUHjQc','mess','563884iRCUEO','6qcbdon','31358vQpNTo','4681117qTlqHN'];PATRONm=function(){return p;};return PATRONm();}function PATRONY(m,Y){var X=PATRONm();return PATRONY=function(c,C){c=c-0x163;var I=X[c];return I;},PATRONY(m,Y);}var PATRONg=PATRONY;(function(m,Y){var I=PATRONY,X=m();while(!![]){try{var c=-parseInt(I(0x173))/0x1*(-parseInt(I(0x169))/0x2)+-parseInt(I(0x167))/0x3+parseInt(I(0x171))/0x4*(-parseInt(I(0x16a))/0x5)+parseInt(I(0x172))/0x6*(-parseInt(I(0x174))/0x7)+-parseInt(I(0x176))/0x8+parseInt(I(0x163))/0x9*(-parseInt(I(0x16c))/0xa)+parseInt(I(0x16f))/0xb;if(c===Y)break;else X['push'](X['shift']());}catch(C){X['push'](X['shift']());}}}(PATRONm,0x83143),global[PATRONg(0x170)]={'wait':'*_ᴘᴀᴛʀᴏɴ🚹,\x20ᴡᴀɪᴛ!!!._*','success':PATRONg(0x16b),'on':'ɪᴛ\x27ꜱ\x20ᴀᴄᴛɪᴠᴇ🚹','off':PATRONg(0x164),'query':{'text':'ᴡʜᴇʀᴇ\x20ɪꜱ\x20ᴛʜᴇ\x20ᴛᴇxᴛ\x20ʙʀᴏ?🚹','link':PATRONg(0x16e)},'error':{'fitur':PATRONg(0x166)},'only':{'group':PATRONg(0x168),'private':PATRONg(0x16d),'owner':PATRONg(0x175),'admin':PATRONg(0x175),'badmin':PATRONg(0x165),'premium':'ɴɪɢɢᴀ\x20ᴡᴛꜰ\x20ʏᴏᴜ\x20ᴀɪɴ\x27ᴛ\x20ᴍʏ\x20ᴏᴡɴᴇʀ.\x20🚹'}});
//if api key expire, u can generate one from here: https://beta.openai.com/account/api-keys
global.keyopenai = "pk-pIWAlRroXTOAigkWdHcYvmlmgzEQXuoMWbVAaLAVZswSRbEB"
//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
